package com.example.listeners;

import com.example.models.Playlist;

public interface PlaylistListener {
    void onRefreshListaPlaylist(Playlist playlist);
}
