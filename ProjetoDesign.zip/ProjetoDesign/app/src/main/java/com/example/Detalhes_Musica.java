package com.example;
import android.widget.ImageView;
import android.widget.TextView;
import com.example.models.Musica;
public class Detalhes_Musica {
    public Musica musica;
    private int idMusica;
    TextView textViewTituloJava;
    ImageView imageViewCapaLivroJava;

}